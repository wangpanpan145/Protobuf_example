Various test protos that are used to stress the code generator.

Many of these were copied from Google's protoc project with only minor changes, hence the Google copyright notices.

Others were created specifically to test Apple's Swift generator.

Some are used in various Test cases, but others serve as tests just by verifying that they compile.
